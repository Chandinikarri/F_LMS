# apps/forms.py

from django import forms
from apps.models import UserProfileInfo, Order
from django.contrib.auth.models import User

class UserForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput())
    class Meta():
        model = User
        fields = ('username','password','email')

class OrderForm(forms.ModelForm):
     class Meta():
         model = Order
         fields = ('Full_Name', 'Address', 'Phonenumber', 'Date', 'Time', 'No_Of_Clothes')

