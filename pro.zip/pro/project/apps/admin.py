from django.contrib import admin
from apps.models import UserProfileInfo, User, Order
# Register your models here.
admin.site.register(UserProfileInfo)
admin.site.register(Order)

