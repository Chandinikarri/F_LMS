# views.py
from django.shortcuts import render
from apps.forms import UserForm,OrderForm
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from django.contrib.auth import authenticate, login as dj_login
from django.contrib.auth.decorators import login_required

def index(request):
    return render(request,'index.html')
def order(request):
    if request.method == 'POST':
      order_form = OrderForm(data=request.POST)
      if request.POST.get('Full_Name') and request.POST.get('Address') and request.POST.get('Phone_Number') and request.POST.get('Date') and request.POST.get('Time') and request.POST.get('No_Of_Clothes'):
          
          order.Full_Name = request.POST.get("Full_Name")
          order.Address = request.POST.get("Address")
          order.Phone_Number = request.POST.get("Phone_Number")
          order.Date = request.POST.get("Date")
          order.Time = request.POST.get("Time")
          order.No_Of_Clothes = request.POST.get("No_Of_Clothes")
          order = order_form.save()
          order.save()
          return render(request, 'order.html',{'order_form' : order_form, 'ordered' : ordered})
      return HttpResponse("Your order is successfull")
    else:
        return render(request, 'order.html')
@login_required
def special(request):
    return HttpResponse("You are logged in !")
@login_required
def user_logout(request):
    logout(request)
    return HttpResponseRedirect(reverse('index'))
def register(request):
    registered = False
    if request.method == 'POST':
        user_form = UserForm(data=request.POST)
      
        if user_form.is_valid() :
            user = user_form.save()
            user.set_password(user.password)
            user.save()
      
            registered = True
            return render(request, 'login.html', {'user_form':user_form,'registered':registered})
        else:
            print(user_form.errors)
    else:
        user_form = UserForm()
      
        return render(request,'registration.html',
                          {'user_form':user_form,
                           'registered':registered})
def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user:
            if user.is_active:
                dj_login(request, user)
                return HttpResponseRedirect(reverse('order'))
            else:
                return HttpResponse("Your account was inactive.")
        else:
            print("Someone tried to login and failed.")
            print("They used username: {} and password: {}".format(username,password))
            return HttpResponse("Invalid login details given")
    else:
        return render(request, 'login.html')

