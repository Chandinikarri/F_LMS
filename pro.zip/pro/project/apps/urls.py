# apps/urls.py
from django.conf.urls import url
from apps import views
from django.urls import path
# SET THE NAMESPACE!
app_name = 'apps'
# Be careful setting the name to just /login use userlogin instead!
urlpatterns=[
    
    path('register',views.register,name='register'),
    path('login',views.login,name='login'),
    path('order',views.order,name='order'),

]
