from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class UserProfileInfo(models.Model):
	user           = models.OneToOneField(User,on_delete=models.CASCADE)
	portfolio_site = models.URLField(blank=True)
	profile_pic    = models.ImageField(upload_to='profile_pics',blank=True)
def __str__(self):
  return self.user.username

class Order(models.Model):
	Full_Name         = models.CharField(max_length = 200,unique = True)	
	Address       = models.CharField(max_length = 200,unique = True)
	Phonenumber   = models.CharField(max_length = 15,unique = True)
	Date          =  models.DateField()
	Time          = models.CharField(max_length = 50,unique = True)
	No_Of_Clothes = models.IntegerField()

